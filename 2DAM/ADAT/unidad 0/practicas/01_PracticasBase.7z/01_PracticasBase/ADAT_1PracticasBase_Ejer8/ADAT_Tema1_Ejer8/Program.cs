﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAT_Tema1_Ejer8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Dime el numero de filas");
            int tamaño = Int32.Parse(Console.ReadLine());
            for (int i = 1; i <= tamaño; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    Console.Write(numero(i, j));
                }



                Console.WriteLine();
            }


            Console.Read();


        }
        static void pintarLinea(int num, int tamaño)
        {
            int blanco = (tamaño * 2 - 1) - (num * 2 + 1);
            for (int i = 0; i < blanco; i++)
            {
                Console.Write("  ");
            }

            for (int i = 1; i < num * 2 + 1; i++)
            {
                Console.Write(numero(num, i));
            }
        }
        static int numero(int n, int k)
        {
            return factorial(n) / (factorial(k) * factorial(n - k));
        }

        static int factorial(int num)
        {
            if (num > 0)
            {
                int valor = num * factorial(num - 1);
                return valor;
            }
            else
                return 1;
        }
    }
}
