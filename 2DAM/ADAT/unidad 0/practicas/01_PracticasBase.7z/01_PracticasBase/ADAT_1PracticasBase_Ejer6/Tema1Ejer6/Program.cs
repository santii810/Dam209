﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema1Ejer6
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = Int32.Parse(Console.ReadLine());

            if (esPerfecto(num))
                Console.Write("El numero es perfecto");
            else
                Console.Write("El numero no es perfecto");
            Console.Read();

        }


        static bool esPerfecto(int num)
        {
            int acum = 0;
            for (int i = 1; i <= num / 2; i++)
            {
                if (num % i == 0)
                    acum += i;
            }
            if (acum == num)
                return true;
            else
                return false;
        }
    }
}
