﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema1Ejer4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, cont = 0;
            bool acierto = false;
            Random r = new Random();
            num = r.Next(0, 51);
            Console.Write("Introduce el numero a acertar");
            do
            {
                cont++;
                int tmp = Int32.Parse(Console.ReadLine());
                if (num == tmp)
                    Console.Write("Has acertado ");
                else if (num > tmp)
                    Console.Write("Demasiado bajo ");
                else
                    Console.Write("Demasiado alto ");
            } while (!acierto && cont < 5);

            Console.ReadLine();
        }
    }
}
