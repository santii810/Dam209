﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema1Ejer5
{
    class Program
    {
        static void Main(string[] args)
        {

            int tamaño = 9;

            for (int i = 0; i < tamaño; i++)
                pintarLinea(i * 2 + 1, tamaño);
            Console.Read();
        }
        static void pintarLinea(int cant, int tamaño)
        {
            int blanco = (tamaño * 2 - 1) - cant;

            for (int i = 0; i < blanco / 2; i++)
                Console.Write(" ");
            for (int i = 0; i < cant; i++)
                Console.Write("*");
            Console.Write("\n");

        }

    }
}
