﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAT_Tema1_Ejer7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Dime los 2 numeros\n");
            int a = Int32.Parse(Console.ReadLine());
            int b = Int32.Parse(Console.ReadLine());
            if (b == sumaDivisores(a) && a == sumaDivisores(b))
                Console.Write("Los numeros son amigos");
            else
                Console.Write("Los numeros no son amigos");
            Console.Read();


        }
        static int sumaDivisores(int num)
        {
            int acum = 0;
            for (int i = 1; i <= num / 2; i++)
            {
                if (num % i == 0)
                    acum += i;
            }
            return acum;
        }
    }
}
