﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema1Ejer3
{
    class Program
    {
        static void Main(string[] args)
        {
            int altura;
            int[] contador = { 0, 0, 0, 0 };
            Console.Write("Introduce una altura negativa para salir");
            do
            {
                altura = Int32.Parse(Console.ReadLine());
                if (altura < 160)
                    contador[0]++;
                else if (altura > 160 && altura <= 170)
                    contador[1]++;
                else if (altura > 170 && altura <= 180)
                    contador[2]++;
                else
                    contador[3]++;
            } while (altura > 0);

            Console.Write("Menores de 160cm : " + contador[0] + "\n Entre 160cm y 170cm: " + contador[1] + "\nEntre 170cm y 180cm: " + contador[2] + "\nMas de 180cm: " + contador[3]);
            Console.ReadLine();
        }
    }
}
