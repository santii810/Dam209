﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Elige la altura para el triángulo de pascal ");
            string cantidad = Console.ReadLine();
            while (IsNumeric(cantidad) == false)
            {
                Console.Write("Por favor introduce un valor numérico ");

                cantidad = Console.ReadLine();
            }

            int largolinea = 1 + (Convert.ToInt32(cantidad) * 2);
            int calculoEsp = 1;
            for (int i = 0; i < Convert.ToInt32(cantidad); i++)
            {
                int esp = 0;
                if ((largolinea - calculoEsp) > 0)
                {
                    
                    esp = (largolinea - calculoEsp) / 2;
                }

                string strast = "";
                string stresp = "";

                int espInt = (largolinea - (i +1))*2;
                for (int j = 0; j < espInt; j++)
                {
                    stresp += " ";
                }


                for (int j = 0; j <i+1; j++)
                {
                    int ncaracteres = 4 - combinatorio(i, j).ToString().Length;
                    for(int k = 0; k< ncaracteres; k++)
                    {
                        strast += " ";
                    }
                    
                    strast += combinatorio(i, j).ToString();
                    
                }

                string linea = stresp + strast ;
                Console.WriteLine(linea);
                calculoEsp = calculoEsp + 2;
            }

            Console.ReadLine();
        }

        public static int multipFactores(int num)
        {
            int multDiv = 1;
            for (int i = 1; i <= num; i++)
            {
                multDiv = multDiv * i;      
            }
            return multDiv;
        }
        
        public static int combinatorio(int n, int k)
        {
            int valor = multipFactores(n) / (multipFactores(k) * multipFactores(n - k));
            return valor;
        }

        public static Boolean IsNumeric(string stringtotest)
        {
            int result;
            return int.TryParse(stringtotest, out result);
        }
    }
}
