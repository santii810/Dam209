﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DINT_2Arrays_Ejer2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] letras = { "T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E" };
            Console.WriteLine("Dime el DNI sin letra");
            int dni = Int32.Parse(Console.ReadLine());
            Console.WriteLine("La letra es: " + letras[dni % 23]);
            Console.ReadLine();
        }
    }
}
