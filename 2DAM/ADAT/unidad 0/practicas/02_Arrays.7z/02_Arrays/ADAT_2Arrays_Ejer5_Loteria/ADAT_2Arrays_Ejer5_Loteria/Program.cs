﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAT_2Arrays_Ejer5_Loteria
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numeros = new int[8];
            Random r = new Random();
            int ale;
            for (int i = 1; i <= 5; i++)
            {
                Console.Write("\n Combinacion " + i + ": " );
            
            for (int j = 0; j < 7; j++)
            {
                do
                {
                    ale = r.Next(1, 50);
                } while (esta(ale, numeros));
                numeros[j] = ale;
            }
            numeros[7] = r.Next(0, 10);
                Console.Write("Numeros: ");
            for (int j = 0; j < 6; j++)
            {
                    Console.Write(numeros[j] + ", ");
            }
            Console.Write("Complementario: " + numeros[6] + ", Reintegro: " + numeros[7]);
        }
            Console.ReadLine();
        }

        static bool esta(int num, int[] numeros)
        {
            foreach (int item in numeros)
            {
                if (item == num)
                    return true;
            }
            return false;
        }
    }

}
