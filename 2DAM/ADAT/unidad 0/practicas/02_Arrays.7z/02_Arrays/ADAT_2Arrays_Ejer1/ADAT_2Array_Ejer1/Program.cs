﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAT_2Array_Ejer1
{
    class Program
    {
        static void Main(string[] args)
        {
            int tamaño = 10;
            int acum = 0;
            int[] vector = new int[tamaño];
            Console.WriteLine("Dime " + tamaño + " numeros");
            for (int i = 0; i < tamaño; i++)
            {
                vector[i] = Int32.Parse(Console.ReadLine());
            }
            foreach (int item in vector)
            {
                acum += item;
            }
            Console.WriteLine(acum);
            Console.ReadLine();
        }
    }
}
