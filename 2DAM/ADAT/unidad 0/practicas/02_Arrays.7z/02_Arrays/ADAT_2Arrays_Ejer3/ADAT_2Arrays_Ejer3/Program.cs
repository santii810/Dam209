﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAT_2Arrays_Ejer3
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            int ale;
            int tamaño = 101;
            double media = 0;

            Console.WriteLine("Dime un numero menor que 100");
            do
            {
                tamaño = Int32.Parse(Console.ReadLine());
            } while (tamaño > 100);

            int[] valores = new int[tamaño];
            for (int i = 0; i < tamaño; i++)
            {
                do
                {
                    ale = r.Next(0,101);

                } while (existe(ale, valores));
                valores[i] = ale;
            }

            foreach (int item in valores)
            {
                media += Convert.ToDouble(item) / tamaño;
            }
            Console.WriteLine("La media es: " + media);

            Console.ReadLine();


        }
        static bool existe(int ale, int[] valores)
        {
            foreach (int item in valores)
            {
                if (item == ale)
                    return true;
            }
            return false;
        }
    }
}
