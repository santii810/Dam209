﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAT_2Arrays_Ejer4_dados
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            int length = 10000;
            int[] dados = { 0, 0, 0, 0, 0, 0, };
            for (int i = 0; i < length; i++)
            {
                dados[r.Next(0, 6)]++;
            }
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Numero " + (i + 1) + ": " + dados[i] +" veces ");
            }
            Console.ReadLine();
        }
    }
}
