﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAT_3Dhont_Votaciones
{
    class Partido
    {
        public string Nombre { get; set; }
        public int Votos { get; set; }
        public int Escaños { get; set; }

        public Partido(string nombre, int votos)
        {
            this.Nombre = nombre;
            this.Votos = votos;
            this.Escaños = 0;
        }
    }
}
