﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAT_3Dhont_Votaciones
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Dime el numero de partidos");
            int num = Int32.Parse(Console.ReadLine());
            Partido[] vector = new Partido[num];
            List<int> votos = new List<int>();
            List<int> tmp = new List<int>();
            //string nombre;
            int tmpVotos, escaños;
            int totalVotos = 0;

            for (int i = 0; i < num; i++)
            {
                //Console.WriteLine("Nombre: ");
                //nombre = Console.ReadLine();
                Console.WriteLine("Numero de votos:");
                tmpVotos = Int32.Parse(Console.ReadLine());
                totalVotos += tmpVotos;
                vector[i] = new Partido("Partido " + (i + 1), tmpVotos);
            }
            Console.WriteLine("Escaños totales: ");
            escaños = int.Parse(Console.ReadLine());

            foreach (Partido item in vector)
                if (item.Votos > totalVotos * 0.03)
                    for (int i = 1; i <= escaños; i++)
                        votos.Add(item.Votos / i);

            votos.Sort();
            votos.Reverse();
            int min = votos[escaños];
            foreach (Partido item in vector)
                if (item.Votos > totalVotos * 0.03)
                    for (int i = 1; i <= escaños; i++)
                        if (item.Votos / i > min)
                            item.Escaños++;

            foreach (Partido item in vector)
                Console.WriteLine("Nombre: " + item.Nombre + " Votos: " + item.Votos + " Escaños: " + item.Escaños);

            Console.ReadLine();
        }
    }
}
