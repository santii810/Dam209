﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _02_IntroThreads
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //referencia página 9 del manual threading.pdf

            Thread t = new Thread(new ThreadStart(Go));
            t.Start(); // Run Go() on the new thread.
            Go(); // Simultaneously run Go() in the main thread.
        }
        private void Go()
        {
            Console.WriteLine("hello!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //referencia página 4 del manual threading.pdf

            Thread t = new Thread(this.WriteY); // Kick off a new thread
            t.Start(); // running WriteY()
                       // Simultaneously, do something on the main thread.
            for (int i = 0; i < 1000; i++) Console.Write("x");
        }

        private void WriteY()
        {
            for (int i = 0; i< 1000; i++) Console.Write ("y");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Feito = false;
            Thread t = new Thread(this.GoHecho);
            t.Start();
            GoHecho();
        }

        bool Feito;

        private void GoHecho()
        {
            if (!Feito)
            {
                Console.WriteLine("Hola Hecho");
                this.Feito = true;                  
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
           

            //primera forma de pasar parámetros
            Thread t1 = new Thread(() => this.Mensaje("Marina"));
            t1.Start();

            //invocación al método en el thread pricipal
            this.Mensaje("Amanda");

            //segunda forma de pasar parámetros con posposición
            Thread t2 = new Thread(this.Mensaje2);
            t2.Start("Brais");
        }

        private void Mensaje(string nombre)
        {
            Console.WriteLine("Hola: " + nombre);
        }

        private void Mensaje2(object nombre)
        {
            string n = (string)nombre;
            Console.WriteLine("Hola: "+n);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(this.WriteY);
            t.Priority = ThreadPriority.Highest;
            Thread.CurrentThread.Priority = ThreadPriority.Lowest;
            t.Start();
            for (int i = 0; i < 1000; i++) Console.Write("X");

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Thread t1 = new Thread(this.NombreThreads);
            Thread t2 = new Thread(this.NombreThreads);
            t1.Name = "primero";
            t2.Name = "segundo";
            t1.Start();
            t2.Start();

        }

        private void NombreThreads()
        {
            Console.WriteLine("****************"+Thread.CurrentThread.Name);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(this.GoLargo);
            t.IsBackground = true;
            t.Start();
        }

        private void GoLargo()
        {
            for (int i = 0; i<1000;i++)
            {
                Thread.Sleep(500);
                Console.WriteLine("hola");
            }
        }
    }
}
