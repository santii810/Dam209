﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace _03_SincroThreads
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int[] numeros = new int[1000];
        int iterador = 0;
        int numero = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            Thread t1 = new Thread(this.rellena);
            Thread t2 = new Thread(this.rellena);
            Thread t3 = new Thread(this.rellena);
            Thread t4 = new Thread(this.rellena);
            Thread t5 = new Thread(this.rellena);

            t1.Start();
            t2.Start();
            t3.Start();
            t4.Start();
            t5.Start();

            //Thread.Sleep(10000);

            //esperar fin ejecución todos los threads
            t1.Join();
            t2.Join();
            t3.Join();
            t4.Join();
            t5.Join();

            //ver contenido del array
            for (int i = 0; i < 1000; i++)
                Console.WriteLine(numeros[i]);

        }
        Object o = new object();
        private void rellena()
        {
            for (int i = 0; i < 200; i++)
            {
                lock (o)
                {
                    numero++;
                    numeros[iterador] = numero;
                    Thread.Sleep(10);
                    iterador++;
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Thread t1 = new Thread(this.RellenaM);
            Thread t2 = new Thread(this.EscribeM);
            t1.Start();
            t2.Start();
        }

        private void RellenaM()
        {
            for (int i = 999; i > 0; i--)
            {
                numeros[i] = i;
                Thread.Sleep(5);
            }
            lock (this)
                Monitor.Pulse(this);
        }

        private void EscribeM()
        {
            lock (this)
                Monitor.Wait(this);
            for (int i = 0; i < 1000; i++)
                Console.WriteLine(numeros[i]);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Thread t1 = new Thread(this.ping);
            Thread t2 = new Thread(this.PONG);
            Thread t3 = new Thread(this.PONG);

            t1.Start();
            t2.Start();
            t3.Start();
        }

        object o1 = new object();
        object o2 = new object();

        private void ping()
        {
            for (int i = 0; i < 1000; i++)
            {
                lock(o2)
                    Monitor.Pulse(o2);
                lock(o1)
                {
                    Monitor.Wait(o1);
                    Console.WriteLine("ping");
                }
            }
        }
        private void PONG()
        {
            for (int i = 0; i < 1000; i++)
            {
                lock (o1)
                    Monitor.Pulse(o1);
                lock (o2)
                {
                    Monitor.Wait(o2);
                    Console.WriteLine("PONG");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Thread[] t = new Thread [5];

            for (int i = 0; i < 5; i++)
            {
                t[i] = new Thread(this.rellena);
                t[i].IsBackground = true;
                t[i].Start();
            }

            //Thread.Sleep(1000);
            t[0].Abort();
            if (t[0].IsAlive)
                Console.WriteLine("t[0] corriendo");
            else
                Console.WriteLine("t[0] FINALIZADO");

            Thread.Sleep(1000);           
            if (t[0].IsAlive)
                Console.WriteLine("t[0] corriendo");
            else
                Console.WriteLine("t[0] FINALIZADO");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //this.textBox1.Text = "hola desde el hilo pricipal";
            //this.EscribirTextBox();
            //Thread t = new Thread(this.EscribirTextBox2);
            //t.Start();
            Thread t = new Thread(this.RellenaTextBox);
            t.Start();


        }

        delegate void DelegadoEscribeTextBox();
        delegate void DelegadoEscribeTextBoxParametros(string s);
        private void RellenaTextBox()
        {
            //invocación al delegado sin parámetros
            DelegadoEscribeTextBox d1 = new  DelegadoEscribeTextBox (this.EscribirTextBox2);
            this.Invoke(d1);

            //invocación al delegado con parámetros
            DelegadoEscribeTextBoxParametros d2 = new DelegadoEscribeTextBoxParametros(this.EscribirTextBoxParm);
            this.Invoke(d2, "hola escrito con parámetros");
        }

        private void EscribirTextBox()
        {
            this.textBox1.Text += "hola desde el hilo pricipal";
        }
        private void EscribirTextBoxParm(String c)
        {
            this.textBox1.Text += c;
        }
        private void EscribirTextBox2()
        {
            
            this.textBox1.Text = "hola desde el hilo secundario";
        }
    }
}
